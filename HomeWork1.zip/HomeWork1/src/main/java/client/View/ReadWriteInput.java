package client.View;

public class ReadWriteInput {
}
